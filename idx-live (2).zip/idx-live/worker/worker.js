// Cloudflare Worker (무료) — 우리 전용 프록시. Yahoo 차트·IDX JSON 을 CORS 허용해서 브라우저에 넘겨준다.
// 배포: dash.cloudflare.com → Workers → Create → 이 파일 붙여넣기 → Deploy → 주소(https://xxx.workers.dev) 를 index.html 의 LIVE_PROXY 에 입력
const ALLOW = ["query1.finance.yahoo.com", "query2.finance.yahoo.com", "www.idx.co.id"];
export default {
  async fetch(req) {
    const u = new URL(req.url);
    const target = u.searchParams.get("url");
    if (!target) return new Response("usage: ?url=<encoded url>", { status: 400 });
    let t; try { t = new URL(target); } catch { return new Response("bad url", { status: 400 }); }
    if (!ALLOW.includes(t.hostname)) return new Response("host not allowed", { status: 403 });
    const r = await fetch(t.toString(), { headers: { "User-Agent": "Mozilla/5.0 (Macintosh) AppleWebKit/537.36 Chrome/133 Safari/537.36", "Accept": "application/json,text/plain,*/*", "Referer": "https://www.idx.co.id/" }, cf: { cacheTtl: 30 } });
    const h = new Headers(r.headers);
    h.set("Access-Control-Allow-Origin", "*"); h.set("Cache-Control", "public, max-age=30"); h.delete("content-security-policy");
    return new Response(r.body, { status: r.status, headers: h });
  }
};
